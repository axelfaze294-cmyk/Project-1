# Eventify: Project Plan (Day 1)

## Purpose
Eventify is an event discovery, registration, and management website built with HTML, CSS, and vanilla JavaScript. Data is stored in the browser (localStorage).

## Features
**Attendee:** browse events, search and filter, view details, register, see confirmation.
**Organizer:** dashboard to create, edit, delete events and view registrations.

## Pages
| Page | File |
|------|------|
| Home | index.html |
| Events | events.html |
| Event details | event-details.html |
| Register | register.html |
| Organizer dashboard | dashboard.html |

About and Contact live as sections on the homepage.

## Design
- Primary: `#6C4CF1`
- Text: `#22223B`
- Background: `#F8F8FC`
- Cards: `#FFFFFF`
- Font: Poppins (Google Fonts), fallback system sans-serif

## Navigation
Home | Events | About | Contact | Organizer Dashboard

## Out of scope
Payments, secure login, email delivery, multi-user sync.

## Sketches (do these on paper, ~15 min each)
- [ ] Homepage
- [ ] Events page
- [ ] Dashboard
