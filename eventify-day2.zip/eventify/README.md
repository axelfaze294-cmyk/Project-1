# Eventify

An event discovery, registration, and management website built with HTML, CSS, and vanilla JavaScript.

## Status
Day 1 of 7: project set up, homepage structure built.

## How to run
Open `index.html` in your browser.

## Features (planned)
- Browse, search, and filter events
- Event details and registration
- Organizer dashboard (create, edit, delete events, view registrations)

## Limitations
Data is stored only in your browser (localStorage). No real payments or login.
