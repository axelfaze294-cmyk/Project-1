// dashboard.js: event CRUD and registration management (Day 6)
