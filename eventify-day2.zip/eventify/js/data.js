// data.js: initial sample events (Day 4)
