// events.js: event rendering, search, filtering (Day 4)
