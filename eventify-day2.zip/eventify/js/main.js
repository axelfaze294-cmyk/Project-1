// main.js: shared navigation and homepage behavior

document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.getElementById("navToggle");
  const navLinks = document.getElementById("navLinks");
  const year = document.getElementById("year");

  // Mobile menu: show or hide the links when the button is clicked
  if (toggle && navLinks) {
    toggle.addEventListener("click", () => {
      const isOpen = navLinks.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(isOpen));
    });
  }

  // Keep the footer year current
  if (year) {
    year.textContent = new Date().getFullYear();
  }
});
