// registration.js: registration validation and confirmation (Day 5)
