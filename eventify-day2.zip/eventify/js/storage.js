// storage.js: reading and writing localStorage (Day 4)
