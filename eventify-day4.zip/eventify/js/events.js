// events.js: event cards, search, and filters.
// Used by the homepage (featured events) and the Events page.
// Needs data.js, storage.js, and main.js to be loaded first.

const FALLBACK_IMAGE = "images/events/default.svg";

/* ---------- Building cards ---------- */

// Returns the HTML for one event card.
function createEventCard(event) {
  const detailsUrl = `event-details.html?id=${encodeURIComponent(event.id)}`;

  return `
    <article class="event-card">
      <img class="event-card-img" src="${escapeHtml(event.image || FALLBACK_IMAGE)}" alt="" loading="lazy">
      <div class="event-card-body">
        <span class="badge">${escapeHtml(event.category || "Event")}</span>
        <h3 class="event-card-title">
          <a href="${detailsUrl}">${escapeHtml(event.title)}</a>
        </h3>
        <p class="event-meta">${escapeHtml(formatDate(event.date))} &middot; ${escapeHtml(event.location || "Location to be announced")}</p>
        <div class="event-card-footer">
          <span class="event-price">${escapeHtml(formatPrice(event.price))}</span>
          <a class="btn btn-small" href="${detailsUrl}">View details</a>
        </div>
      </div>
    </article>
  `;
}

// Puts a list of events into a container as cards.
function renderCards(events, container) {
  container.innerHTML = events.map(createEventCard).join("");

  // If an image file is missing, swap in the default picture (once, to avoid loops).
  container.querySelectorAll("img").forEach((img) => {
    img.addEventListener("error", () => {
      img.src = FALLBACK_IMAGE;
    }, { once: true });
  });
}

// Returns a new list sorted by date, soonest first.
function sortByDate(events) {
  return [...events].sort((a, b) => String(a.date).localeCompare(String(b.date)));
}

/* ---------- Filtering ---------- */

// Every word typed must appear in the title or the location.
function matchesSearch(event, query) {
  const words = query.toLowerCase().split(/\s+/).filter(Boolean);
  const text = `${event.title} ${event.location}`.toLowerCase();

  return words.every((word) => text.includes(word));
}

function matchesCategory(event, category) {
  return category === "all" || event.category === category;
}

function matchesPrice(event, price) {
  if (price === "free") return Number(event.price) === 0;
  if (price === "paid") return Number(event.price) > 0;
  return true;
}

// Keeps only the events that pass all three checks at the same time.
function filterEvents(events, filters) {
  return events.filter((event) =>
    matchesSearch(event, filters.query) &&
    matchesCategory(event, filters.category) &&
    matchesPrice(event, filters.price)
  );
}

/* ---------- Homepage: featured events ---------- */

function initFeatured() {
  const container = document.getElementById("featuredEvents");
  if (!container) return;

  const events = getEvents();
  const upcoming = events.filter((event) => String(event.date) >= todayISO());

  // Use upcoming events when there are any, otherwise fall back to all events.
  const featured = sortByDate(upcoming.length ? upcoming : events).slice(0, 3);

  if (featured.length === 0) {
    container.innerHTML = '<p class="placeholder-note">No events yet. Check back soon.</p>';
    return;
  }

  renderCards(featured, container);
}

/* ---------- Events page: search and filters ---------- */

function initEventsPage() {
  const grid = document.getElementById("eventGrid");
  const form = document.getElementById("filterForm");
  if (!grid || !form) return;

  const searchInput = document.getElementById("searchInput");
  const categoryFilter = document.getElementById("categoryFilter");
  const priceFilter = document.getElementById("priceFilter");
  const resultsCount = document.getElementById("resultsCount");
  const noResults = document.getElementById("noResults");
  const noResultsTitle = noResults.querySelector("h2");
  const noResultsText = noResults.querySelector("p");

  const allEvents = getEvents();

  function update() {
    const filters = {
      query: searchInput.value,
      category: categoryFilter.value,
      price: priceFilter.value
    };

    const results = sortByDate(filterEvents(allEvents, filters));
    renderCards(results, grid);

    const noun = allEvents.length === 1 ? "event" : "events";
    resultsCount.textContent = `Showing ${results.length} of ${allEvents.length} ${noun}`;

    if (allEvents.length === 0) {
      noResultsTitle.textContent = "No events yet";
      noResultsText.textContent = "Check back soon for new events.";
    } else {
      noResultsTitle.textContent = "No events found";
      noResultsText.textContent = "Try a different search or clear the filters.";
    }
    noResults.hidden = results.length > 0;
  }

  // Start from the homepage search (events.html?q=music) if there is one.
  const params = new URLSearchParams(window.location.search);
  searchInput.value = params.get("q") || "";

  const requestedCategory = params.get("category");
  const knownCategory = [...categoryFilter.options].some((option) => option.value === requestedCategory);
  if (knownCategory) {
    categoryFilter.value = requestedCategory;
  }

  // Update the list whenever any control changes.
  form.addEventListener("input", update);
  form.addEventListener("change", update);

  // Pressing Enter in the search box should not reload the page.
  form.addEventListener("submit", (event) => event.preventDefault());

  // The reset button clears the controls after this event fires, so wait a moment.
  form.addEventListener("reset", () => setTimeout(update, 0));

  update();
}

document.addEventListener("DOMContentLoaded", () => {
  initFeatured();
  initEventsPage();
});
