// data.js: initial sample events
// Each event needs a unique id. The dashboard will create new ids later.
// Dates use the YYYY-MM-DD format. A price of 0 means the event is free.

const initialEvents = [
  {
    id: 1,
    title: "Tech Conference 2026",
    category: "Technology",
    date: "2026-11-20",
    location: "Dhaka",
    price: 500,
    capacity: 100,
    image: "images/events/tech.svg",
    description: "A full day of talks and workshops for developers, designers, and technology enthusiasts."
  },
  {
    id: 2,
    title: "Dhaka Music Festival",
    category: "Music",
    date: "2026-11-25",
    location: "Dhaka",
    price: 800,
    capacity: 200,
    image: "images/events/music.svg",
    description: "An evening of live music from local bands and solo artists, with food stalls on site."
  },
  {
    id: 3,
    title: "Startup Pitch Night",
    category: "Business",
    date: "2026-11-14",
    location: "Dhaka",
    price: 0,
    capacity: 80,
    image: "images/events/business.svg",
    description: "Ten early-stage startups pitch to a panel of investors. Free entry, with networking afterward."
  },
  {
    id: 4,
    title: "Contemporary Art Exhibition",
    category: "Art",
    date: "2026-12-03",
    location: "Dhaka",
    price: 0,
    capacity: 150,
    image: "images/events/art.svg",
    description: "Paintings, sculpture, and mixed media from emerging Bangladeshi artists, with a guided tour at noon."
  },
  {
    id: 5,
    title: "Chattogram City Marathon",
    category: "Sports",
    date: "2026-12-12",
    location: "Chattogram",
    price: 300,
    capacity: 500,
    image: "images/events/sports.svg",
    description: "Choose a 5 km, 10 km, or half-marathon route along the city's waterfront. Medals for all finishers."
  },
  {
    id: 6,
    title: "Sylhet Street Food Carnival",
    category: "Food",
    date: "2026-11-28",
    location: "Sylhet",
    price: 200,
    capacity: 300,
    image: "images/events/food.svg",
    description: "Over forty vendors serving regional dishes, desserts, and tea, plus live cooking demonstrations."
  },
  {
    id: 7,
    title: "Web Development Bootcamp",
    category: "Education",
    date: "2026-12-05",
    location: "Dhaka",
    price: 1500,
    capacity: 40,
    image: "images/events/education.svg",
    description: "A hands-on weekend course covering HTML, CSS, and JavaScript. Bring your own laptop."
  },
  {
    id: 8,
    title: "AI and Data Science Summit",
    category: "Technology",
    date: "2026-12-18",
    location: "Dhaka",
    price: 1200,
    capacity: 120,
    image: "images/events/tech.svg",
    description: "Researchers and practitioners share how machine learning is being used in industry today."
  },
  {
    id: 9,
    title: "Acoustic Evening by the Lake",
    category: "Music",
    date: "2026-12-20",
    location: "Khulna",
    price: 400,
    capacity: 90,
    image: "images/events/music.svg",
    description: "A relaxed outdoor concert of acoustic sets as the sun goes down. Seating is limited."
  },
  {
    id: 10,
    title: "Women in Business Forum",
    category: "Business",
    date: "2027-01-09",
    location: "Rajshahi",
    price: 600,
    capacity: 100,
    image: "images/events/business.svg",
    description: "Panels, mentoring sessions, and networking for women entrepreneurs and professionals."
  }
];
