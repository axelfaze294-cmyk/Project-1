// registration.js: registration form, validation, capacity check, and confirmation.
// Needs data.js, storage.js, and main.js to be loaded first.

// Price for a number of tickets.
function calculateTotal(price, quantity) {
  return price * quantity;
}

// Simple email check: something@something.something, with no spaces.
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Shows (or clears) an error message under a field and marks the field as invalid.
function showFieldError(input, errorElement, message) {
  errorElement.textContent = message;
  input.classList.toggle("invalid", message !== "");
  input.setAttribute("aria-invalid", message !== "" ? "true" : "false");
}

// Returns a new registration number: one higher than the biggest existing one.
function nextRegistrationId(registrations) {
  const ids = registrations.map((registration) => Number(registration.id) || 0);
  return Math.max(0, ...ids) + 1;
}

function ticketWord(count) {
  return count === 1 ? "ticket" : "tickets";
}

function initRegistrationPage() {
  const form = document.getElementById("registerForm");
  if (!form) return;

  const eventSelect = document.getElementById("eventSelect");
  const eventInfo = document.getElementById("eventInfo");
  const eventError = document.getElementById("eventError");
  const nameInput = document.getElementById("fullName");
  const nameError = document.getElementById("nameError");
  const emailInput = document.getElementById("email");
  const emailError = document.getElementById("emailError");
  const quantityInput = document.getElementById("quantity");
  const quantityError = document.getElementById("quantityError");
  const totalPrice = document.getElementById("totalPrice");
  const formError = document.getElementById("formError");
  const confirmation = document.getElementById("confirmation");
  const confirmationText = document.getElementById("confirmationText");

  const events = getEvents();

  // Link each field to its error message for screen readers.
  [
    [eventSelect, eventError],
    [nameInput, nameError],
    [emailInput, emailError],
    [quantityInput, quantityError]
  ].forEach(([input, error]) => input.setAttribute("aria-describedby", error.id));

  /* ----- Event list ----- */

  // Fill the dropdown, soonest event first. Sold-out events are shown but cannot be chosen.
  [...events]
    .sort((a, b) => String(a.date).localeCompare(String(b.date)))
    .forEach((event) => {
      const option = document.createElement("option");
      const soldOut = getRemainingTickets(event) === 0;

      option.value = String(event.id);
      option.textContent = `${event.title} (${formatDate(event.date)})${soldOut ? " - sold out" : ""}`;
      option.disabled = soldOut;
      eventSelect.appendChild(option);
    });

  function selectedEvent() {
    return events.find((event) => String(event.id) === eventSelect.value) || null;
  }

  // Preselect the event from the address (register.html?id=3).
  const requestedId = new URLSearchParams(window.location.search).get("id");
  if (requestedId !== null) {
    const match = events.find((event) => String(event.id) === requestedId.trim());

    if (match) {
      eventSelect.value = String(match.id);
    } else {
      eventError.textContent = "We could not find that event. Please choose one from the list.";
    }
  }

  /* ----- Event summary and live total ----- */

  function updateTotal() {
    const event = selectedEvent();
    const raw = quantityInput.value.trim();
    const quantity = Number(raw);
    const validQuantity = raw !== "" && Number.isInteger(quantity) && quantity >= 1;

    if (!event || !validQuantity) {
      totalPrice.textContent = "৳0";
      return;
    }

    const total = calculateTotal(Number(event.price) || 0, quantity);
    totalPrice.textContent = total === 0 ? "Free" : formatPrice(total);
  }

  function updateEventInfo() {
    const event = selectedEvent();

    if (!event) {
      eventInfo.textContent = "";
      quantityInput.removeAttribute("max");
      updateTotal();
      return;
    }

    const remaining = getRemainingTickets(event);
    const price = Number(event.price) || 0;
    const parts = [
      formatDate(event.date),
      event.location || "Location to be announced",
      price === 0 ? "Free" : `${formatPrice(price)} per ticket`,
      remaining > 0 ? `${remaining} ${ticketWord(remaining)} left` : "Sold out"
    ];

    eventInfo.textContent = parts.join(" · ");

    if (remaining > 0) {
      quantityInput.max = String(remaining);
    } else {
      quantityInput.removeAttribute("max");
    }

    updateTotal();
  }

  /* ----- Validation: each function returns an error message, or "" if valid ----- */

  function validateEvent() {
    const event = selectedEvent();
    let message = "";

    if (!event) {
      message = "Please choose an event.";
    } else if (getRemainingTickets(event) === 0) {
      message = "This event is sold out. Please choose another event.";
    }

    showFieldError(eventSelect, eventError, message);
    return message;
  }

  function validateName() {
    const name = nameInput.value.trim();
    let message = "";

    if (name === "") {
      message = "Please enter your full name.";
    } else if (name.length < 2) {
      message = "Your name must have at least 2 characters.";
    }

    showFieldError(nameInput, nameError, message);
    return message;
  }

  function validateEmail() {
    const email = emailInput.value.trim();
    let message = "";

    if (email === "") {
      message = "Please enter your email address.";
    } else if (!EMAIL_PATTERN.test(email)) {
      message = "Please enter a valid email address, like name@example.com.";
    }

    showFieldError(emailInput, emailError, message);
    return message;
  }

  function validateQuantity() {
    const raw = quantityInput.value.trim();
    const quantity = Number(raw);
    const event = selectedEvent();
    let message = "";

    if (raw === "" || !Number.isInteger(quantity) || quantity < 1) {
      message = "Enter a whole number of tickets, 1 or more.";
    } else if (event) {
      // Read the saved registrations again, in case another tab registered meanwhile.
      const remaining = getRemainingTickets(event);

      if (remaining === 0) {
        message = "No tickets are left for this event.";
      } else if (quantity > remaining) {
        message = `Only ${remaining} ${ticketWord(remaining)} left for this event.`;
      }
    }

    showFieldError(quantityInput, quantityError, message);
    return message;
  }

  /* ----- Events: update as the visitor types ----- */

  eventSelect.addEventListener("change", () => {
    showFieldError(eventSelect, eventError, "");
    formError.textContent = "";
    updateEventInfo();
  });

  nameInput.addEventListener("input", () => showFieldError(nameInput, nameError, ""));
  emailInput.addEventListener("input", () => showFieldError(emailInput, emailError, ""));

  quantityInput.addEventListener("input", () => {
    showFieldError(quantityInput, quantityError, "");
    updateTotal();
  });

  /* ----- Submit ----- */

  form.addEventListener("submit", (submitEvent) => {
    submitEvent.preventDefault();
    formError.textContent = "";
    updateEventInfo();

    // Run every check so all problems show at once.
    const checks = [
      [eventSelect, validateEvent()],
      [nameInput, validateName()],
      [emailInput, validateEmail()],
      [quantityInput, validateQuantity()]
    ];

    const firstProblem = checks.find(([, message]) => message !== "");
    if (firstProblem) {
      firstProblem[0].focus();
      return;
    }

    const event = selectedEvent();
    const quantity = Number(quantityInput.value);
    const registrations = getRegistrations();

    const registration = {
      id: nextRegistrationId(registrations),
      eventId: event.id,
      name: nameInput.value.trim(),
      email: emailInput.value.trim(),
      quantity: quantity,
      total: calculateTotal(Number(event.price) || 0, quantity),
      date: new Date().toISOString()
    };

    registrations.push(registration);

    if (!saveRegistrations(registrations)) {
      formError.textContent = "Your registration could not be saved. Your browser storage may be full or blocked.";
      return;
    }

    showConfirmation(registration, event);
  });

  function showConfirmation(registration, event) {
    const totalText = registration.total === 0 ? "Free" : formatPrice(registration.total);

    // textContent keeps the typed name from being treated as HTML.
    confirmationText.textContent =
      `Thank you, ${registration.name}. You are registered for ${event.title} on ${formatDate(event.date)}. ` +
      `Tickets: ${registration.quantity}. Total: ${totalText}. ` +
      `Your registration number is #${registration.id}.`;

    form.hidden = true;
    confirmation.hidden = false;

    // Move focus to the confirmation so screen readers announce it.
    const heading = confirmation.querySelector("h2");
    heading.tabIndex = -1;
    heading.focus();
  }

  updateEventInfo();
}

document.addEventListener("DOMContentLoaded", initRegistrationPage);
