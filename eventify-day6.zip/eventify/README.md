# Eventify

An event discovery, registration, and management website built with HTML, CSS, and vanilla JavaScript.

## Status
Day 6 of 7: attendee journey and organizer dashboard are working. Day 7 is testing, polish, and the demo.

## How to run
Open `index.html` in your browser.

## Features (planned)
- Browse, search, and filter events
- Event details and registration
- Organizer dashboard (create, edit, delete events, view registrations)

## Limitations
Data is stored only in your browser (localStorage). No real payments or login.
