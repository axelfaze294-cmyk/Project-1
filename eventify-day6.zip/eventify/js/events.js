// events.js: event cards, search, and filters.
// Used by the homepage (featured events) and the Events page.
// Needs data.js, storage.js, and main.js to be loaded first.

const FALLBACK_IMAGE = "images/events/default.svg";

/* ---------- Building cards ---------- */

// Returns the HTML for one event card.
function createEventCard(event) {
  const detailsUrl = `event-details.html?id=${encodeURIComponent(event.id)}`;

  return `
    <article class="event-card">
      <img class="event-card-img" src="${escapeHtml(event.image || FALLBACK_IMAGE)}" alt="" loading="lazy">
      <div class="event-card-body">
        <span class="badge">${escapeHtml(event.category || "Event")}</span>
        <h3 class="event-card-title">
          <a href="${detailsUrl}">${escapeHtml(event.title)}</a>
        </h3>
        <p class="event-meta">${escapeHtml(formatDate(event.date))} &middot; ${escapeHtml(event.location || "Location to be announced")}</p>
        <div class="event-card-footer">
          <span class="event-price">${escapeHtml(formatPrice(event.price))}</span>
          <a class="btn btn-small" href="${detailsUrl}">View details</a>
        </div>
      </div>
    </article>
  `;
}

// Puts a list of events into a container as cards.
function renderCards(events, container) {
  container.innerHTML = events.map(createEventCard).join("");

  // If an image file is missing, swap in the default picture (once, to avoid loops).
  container.querySelectorAll("img").forEach((img) => {
    img.addEventListener("error", () => {
      img.src = FALLBACK_IMAGE;
    }, { once: true });
  });
}

/* ---------- Filtering ---------- */

// Every word typed must appear in the title or the location.
function matchesSearch(event, query) {
  const words = query.toLowerCase().split(/\s+/).filter(Boolean);
  const text = `${event.title} ${event.location}`.toLowerCase();

  return words.every((word) => text.includes(word));
}

function matchesCategory(event, category) {
  return category === "all" || event.category === category;
}

function matchesPrice(event, price) {
  if (price === "free") return Number(event.price) === 0;
  if (price === "paid") return Number(event.price) > 0;
  return true;
}

// Keeps only the events that pass all three checks at the same time.
function filterEvents(events, filters) {
  return events.filter((event) =>
    matchesSearch(event, filters.query) &&
    matchesCategory(event, filters.category) &&
    matchesPrice(event, filters.price)
  );
}

/* ---------- Homepage: featured events ---------- */

function initFeatured() {
  const container = document.getElementById("featuredEvents");
  if (!container) return;

  const events = getEvents();
  const upcoming = events.filter((event) => String(event.date) >= todayISO());

  // Use upcoming events when there are any, otherwise fall back to all events.
  const featured = sortByDate(upcoming.length ? upcoming : events).slice(0, 3);

  if (featured.length === 0) {
    container.innerHTML = '<p class="placeholder-note">No events yet. Check back soon.</p>';
    return;
  }

  renderCards(featured, container);
}

/* ---------- Events page: search and filters ---------- */

function initEventsPage() {
  const grid = document.getElementById("eventGrid");
  const form = document.getElementById("filterForm");
  if (!grid || !form) return;

  const searchInput = document.getElementById("searchInput");
  const categoryFilter = document.getElementById("categoryFilter");
  const priceFilter = document.getElementById("priceFilter");
  const resultsCount = document.getElementById("resultsCount");
  const noResults = document.getElementById("noResults");
  const noResultsTitle = noResults.querySelector("h2");
  const noResultsText = noResults.querySelector("p");

  const allEvents = getEvents();

  function update() {
    const filters = {
      query: searchInput.value,
      category: categoryFilter.value,
      price: priceFilter.value
    };

    const results = sortByDate(filterEvents(allEvents, filters));
    renderCards(results, grid);

    const noun = allEvents.length === 1 ? "event" : "events";
    resultsCount.textContent = `Showing ${results.length} of ${allEvents.length} ${noun}`;

    if (allEvents.length === 0) {
      noResultsTitle.textContent = "No events yet";
      noResultsText.textContent = "Check back soon for new events.";
    } else {
      noResultsTitle.textContent = "No events found";
      noResultsText.textContent = "Try a different search or clear the filters.";
    }
    noResults.hidden = results.length > 0;
  }

  // Start from the homepage search (events.html?q=music) if there is one.
  const params = new URLSearchParams(window.location.search);
  searchInput.value = params.get("q") || "";

  const requestedCategory = params.get("category");
  const knownCategory = [...categoryFilter.options].some((option) => option.value === requestedCategory);
  if (knownCategory) {
    categoryFilter.value = requestedCategory;
  }

  // Update the list whenever any control changes.
  form.addEventListener("input", update);
  form.addEventListener("change", update);

  // Pressing Enter in the search box should not reload the page.
  form.addEventListener("submit", (event) => event.preventDefault());

  // The reset button clears the controls after this event fires, so wait a moment.
  form.addEventListener("reset", () => setTimeout(update, 0));

  update();
}

/* ---------- Event details page ---------- */

function initEventDetails() {
  const article = document.getElementById("eventDetails");
  const errorBox = document.getElementById("detailError");
  if (!article || !errorBox) return;

  // The address looks like event-details.html?id=3
  const id = new URLSearchParams(window.location.search).get("id");
  const event = id === null ? undefined : getEvents().find((item) => String(item.id) === id.trim());

  // Missing or unknown id: show the error message instead of the event.
  if (!event) {
    article.hidden = true;
    errorBox.hidden = false;
    document.title = "Event not found | Eventify";
    return;
  }

  const image = document.getElementById("detailImage");
  image.src = event.image || FALLBACK_IMAGE;
  image.alt = event.title;
  image.addEventListener("error", () => {
    image.src = FALLBACK_IMAGE;
  }, { once: true });

  // textContent (not innerHTML) keeps typed text from being treated as HTML.
  document.getElementById("detailCategory").textContent = event.category || "Event";
  document.getElementById("detailTitle").textContent = event.title;
  document.getElementById("detailDate").textContent = formatDate(event.date);
  document.getElementById("detailLocation").textContent = event.location || "To be announced";
  document.getElementById("detailPrice").textContent = formatPrice(event.price);
  document.getElementById("detailDescription").textContent = event.description || "No description yet.";
  document.title = `${event.title} | Eventify`;

  const remaining = getRemainingTickets(event);
  const seats = document.getElementById("detailSeats");
  const registerLink = document.getElementById("registerLink");

  if (remaining > 0) {
    seats.textContent = `${remaining} of ${Number(event.capacity)} left`;
    registerLink.href = `register.html?id=${encodeURIComponent(event.id)}`;
  } else {
    // Sold out: turn the button into a disabled label.
    seats.textContent = "Sold out";
    registerLink.textContent = "Sold out";
    registerLink.removeAttribute("href");
    registerLink.setAttribute("aria-disabled", "true");
  }
}

document.addEventListener("DOMContentLoaded", () => {
  initFeatured();
  initEventsPage();
  initEventDetails();
});
