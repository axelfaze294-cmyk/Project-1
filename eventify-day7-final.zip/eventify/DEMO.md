# Eventify: 3-Minute Demo Script

Show the attendee journey first, then the organizer journey. Practice it twice with a timer.

## Before you start (1 minute)

- Open `dashboard.html` and click **Reset demo data** so you start from a known state.
- Open `index.html` at 100% zoom. Keep VS Code open on `js/` for the code tour.
- Know how to open DevTools device mode (F12, then the phone icon) to show the phone layout.

## The script

| Time | Do this | Say this |
| --- | --- | --- |
| 0:00 | Home page | "Eventify is our CSE 2216 lab project. It lets people find and register for events, and lets organizers manage them. It uses only HTML, CSS, and JavaScript." |
| 0:20 | Type **music** in the hero search and press Search | "Search takes us to the events page with the results already filtered." |
| 0:35 | Clear filters. Pick **Technology**, change Sort to **Price: high to low** | "Search, category, price, and sort all work together. Cards also show Sold out and tickets-left labels." |
| 1:00 | Open an event, then click **Register** | "Each card opens a details page. The address holds the event id, and JavaScript reads it." |
| 1:15 | Type a bad email, ask for more tickets than are left, then submit | "The form checks every field and shows an error next to it. It also checks capacity, so an event cannot be oversold." |
| 1:40 | Fix the form, set 2 tickets, submit | "The total updates as I type. After submitting, I get a confirmation with a registration number." |
| 1:55 | Open **Organizer Dashboard** | "Now the organizer side. The registration I just made is here, and the stats and the Registered column updated." |
| 2:10 | Add an event, for example "Programming Contest 2026" | "I can create an event with validation, edit it, or delete it with a confirmation." |
| 2:30 | Open the Events page and show the new event, then show phone layout | "It appears on the public page immediately, and the layout adapts to a phone." |
| 2:45 | Show `storage.js` in VS Code | "Everything is saved in the browser's localStorage, with separate keys for events and registrations. There is no backend, so data stays in this browser." |
| 2:55 | Back to the home page | "Next steps would be a real backend with logins and payments." |

## If something goes wrong

- Page looks empty or odd: dashboard, **Reset demo data**.
- Typed something wrong in a form: press F5 and redo it.
- Out of time: skip the phone view first, then the code tour.

## Questions you may be asked

**Why localStorage?** It keeps data in the browser without a server. It is enough for a front-end demonstration, but it is not shared between devices.

**How do you stop an event from being oversold?** Tickets left is capacity minus the registered tickets. The form checks it again when you press submit, and the dashboard will not let capacity go below the tickets already sold.

**How does the details page know which event to show?** The link contains `?id=3`. `URLSearchParams` reads it, and `find()` looks up the matching event. An unknown id shows an error message.

**What does `escapeHtml()` do?** It turns characters like `<` into harmless text, so a title like `<script>` is shown as text instead of running as code.

**How do search and filters work together?** `filterEvents()` uses `filter()` and keeps an event only if it matches the search words, the category, and the price type at once. `sortEvents()` then sorts the result.

**What happens if the saved data is damaged?** `readData()` catches the error and returns a safe default, and `getEvents()` falls back to the sample events.

**What happens to registrations when an event is deleted?** They are deleted with it, and the confirmation message says how many.

**What would you add with a backend?** User accounts, a real database shared by all users, email confirmations, payments, and organizer-only access to the dashboard.
