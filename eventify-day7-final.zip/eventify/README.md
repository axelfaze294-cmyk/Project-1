# Eventify

Eventify is an event discovery, registration, and management website. Attendees can find events, register, and get a confirmation. Organizers can create, edit, and delete events and see who registered.

It is built with **HTML, CSS, and vanilla JavaScript only** (no frameworks, no backend). Data is saved in the browser with `localStorage`.

**Course project:** CSE 2216 Lab, for Afsana Zaman Nipa
**Team:** Nusrat Jahan (CSE 2324021) and Abrar Faiyaj (CSE 2324019)

![Home page](screenshots/01-home.png)

## Features

**For attendees**
- Browse upcoming events as cards (category, date, location, price)
- Search by title or location, filter by category and free/paid, and sort by date, price, or title (all work together)
- "Sold out" and "N tickets left" labels on event cards
- Event details page with description and live "tickets left" count
- Registration form with validation (name, email, ticket quantity), a live total price, and a capacity check so an event can never be oversold
- Confirmation message with a registration number

**For organizers (Organizer Dashboard)**
- Summary numbers: total events and total registrations
- Create events (title, category, date, location, price, capacity, image, description)
- Edit an event in place, or delete it (with a confirmation that warns about its registrations)
- Registrations table: name, email, event, tickets, and date, newest first
- "Reset demo data" button to restore the sample events

**Quality**
- Responsive from 320px phones to wide desktops
- Keyboard friendly: skip link, visible focus rings, accessible mobile menu
- Labelled form fields, error messages tied to their fields, and text contrast of at least 4.5:1
- Handles empty lists, invalid event ids, and damaged saved data without crashing

## Screenshots

| Events (search, filters, sort, labels) | Event details |
| --- | --- |
| ![Events page](screenshots/02-events.png) | ![Event details](screenshots/03-event-details.png) |

| Registration with live total | Organizer dashboard |
| --- | --- |
| ![Registration form](screenshots/04-register.png) | ![Dashboard](screenshots/05-dashboard.png) |

| On a phone |
| --- |
| <img src="screenshots/06-mobile-events.png" alt="Events page on a phone" width="300"> |

## How to run

No installation is needed.

1. Download or clone the project folder.
2. Open `index.html` in a browser (double-click it).

Optional: in VS Code, right-click `index.html` and choose **Open with Live Server**, or run `python -m http.server` in the project folder and open `http://localhost:8000`.

The Poppins font loads from Google Fonts, so it needs an internet connection. Without one, the site falls back to a system font and still works.

## Project structure

```
eventify/
├── index.html            Home: hero search, featured events, About, Contact
├── events.html           All events with search, filters, and sorting
├── event-details.html    One event (opened with ?id=3)
├── register.html         Registration form (opened with ?id=3 to preselect an event)
├── dashboard.html        Organizer dashboard
├── css/
│   └── style.css         All styles (variables, components, responsive rules)
├── js/
│   ├── data.js           Sample events
│   ├── storage.js        Reading and writing localStorage, ticket counts
│   ├── main.js           Shared helpers, mobile menu, footer year
│   ├── events.js         Cards, search, filters, sorting, details page
│   ├── registration.js   Registration form, validation, saving
│   └── dashboard.js      Create, edit, delete events; registrations table
├── images/               Event illustrations and favicon
├── screenshots/          Images used in this README
├── PLAN.md               Original plan
├── DEMO.md               3-minute demo script and likely questions
└── TESTING.md            Manual test checklist
```

Each page loads its scripts in this order: `data.js`, `storage.js`, `main.js`, then the page's own script. Later files use functions from earlier ones.

## How it works

**Data.** An event is a plain object:

```js
{ id: 1, title: "Tech Conference 2026", category: "Technology", date: "2026-11-20",
  location: "Dhaka", price: 500, capacity: 100, image: "images/events/tech.svg",
  description: "..." }
```

A registration is also an object: `{ id, eventId, name, email, quantity, total, date }`.

**Storage.** The first time the site opens, the sample events from `data.js` are saved to `localStorage` under `eventify_events`. Registrations are saved under `eventify_registrations`. From then on, every page reads and writes those two keys through the helpers in `storage.js`, so a change made on the dashboard shows up on the public pages straight away.

**Tickets left.** `capacity` minus the sum of `quantity` for that event's registrations. The registration form re-checks this at the moment of submitting, and the dashboard will not let capacity drop below tickets already registered.

**Pages and ids.** Cards link to `event-details.html?id=3`. The page reads the id with `URLSearchParams` and finds the matching event. A missing or unknown id shows an "Event not found" message.

**Filtering.** `filterEvents()` keeps an event only if it passes the search, category, and price checks at the same time. `sortEvents()` then orders the result.

**Safety.** Text typed by users (titles, names) is passed through `escapeHtml()` before it is placed in the page, so typed HTML is shown as plain text and never runs.

## Limitations

- Data lives only in the browser that created it. Another browser or device starts with the sample data.
- There is no real payment, login, or email. The dashboard is open to anyone who finds it. This is a front-end demonstration, not a production booking system.
- Event pictures are included illustrations. Organizers can type their own image path or address.
- Registration is not blocked for events whose date has passed.

## Deploy (optional)

**GitHub Pages:** create a repository, upload all the files (keeping the folders), then go to **Settings, Pages**, choose the `main` branch and the root folder, and save. The site appears at `https://<username>.github.io/<repository>/`.

**Netlify:** open [app.netlify.com/drop](https://app.netlify.com/drop) and drag the whole project folder onto the page.

All links are relative, so no changes are needed.

## Resetting the demo data

Use **Reset demo data** on the dashboard, or clear the site's data in your browser. This also helps after changing the shape of the event objects in `data.js`, because saved data overrides it.
