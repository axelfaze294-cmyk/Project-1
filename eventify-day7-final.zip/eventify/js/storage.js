// storage.js: reading and writing browser storage (localStorage)
// Load this file after data.js and before any script that uses these functions.

const EVENTS_KEY = "eventify_events";
const REGISTRATIONS_KEY = "eventify_registrations";

// Read and parse a saved value. Returns `fallback` if nothing is saved,
// the saved text is not valid JSON, or storage is unavailable.
function readData(key, fallback = []) {
  try {
    const value = localStorage.getItem(key);

    return value === null
      ? fallback
      : JSON.parse(value);
  } catch {
    return fallback;
  }
}

// Save a value as JSON. Returns true on success, false if storage failed
// (for example, storage is full or blocked in a private window).
function writeData(key, data) {
  try {
    localStorage.setItem(key, JSON.stringify(data));
    return true;
  } catch {
    return false;
  }
}

// An event is usable only if it is an object with an id and a title.
function isValidEvent(event) {
  return Boolean(
    event &&
    typeof event === "object" &&
    event.id !== undefined &&
    event.id !== null &&
    typeof event.title === "string" &&
    event.title.trim() !== ""
  );
}

// Get all events. On the first visit (or if the saved data is damaged),
// save the sample events and return them. Unusable entries are skipped.
function getEvents() {
  const saved = readData(EVENTS_KEY, null);

  if (!Array.isArray(saved)) {
    writeData(EVENTS_KEY, initialEvents);
    return initialEvents.map((event) => ({ ...event }));
  }

  return saved.filter(isValidEvent);
}

function saveEvents(events) {
  return writeData(EVENTS_KEY, events);
}

// Get all registrations. Always returns an array of objects.
function getRegistrations() {
  const saved = readData(REGISTRATIONS_KEY, []);

  if (!Array.isArray(saved)) {
    return [];
  }

  return saved.filter((item) => item && typeof item === "object");
}

function saveRegistrations(registrations) {
  return writeData(REGISTRATIONS_KEY, registrations);
}

// Tickets registered for every event, counted in one pass.
// Returns an object like { "1": 12, "3": 40 } (event id -> tickets sold).
function getTicketsSoldMap() {
  const sold = {};

  getRegistrations().forEach((registration) => {
    const key = String(registration.eventId);
    sold[key] = (sold[key] || 0) + (Number(registration.quantity) || 0);
  });

  return sold;
}

// How many tickets have been registered for one event.
function getTicketsSold(eventId) {
  return getTicketsSoldMap()[String(eventId)] || 0;
}

// Tickets still available: capacity minus tickets already registered.
function getRemainingTickets(event) {
  const capacity = Number(event.capacity) || 0;
  return Math.max(0, capacity - getTicketsSold(event.id));
}
