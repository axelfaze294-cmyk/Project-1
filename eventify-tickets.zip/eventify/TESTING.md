# Eventify: Manual Test Checklist

Tick each box as you test. Use Reset demo data (on the dashboard) before starting. Test in Chrome first, then another browser if you can.

## Attendee: browsing

- [ ] Home page shows 3 featured events
- [ ] Hero search sends you to the Events page with your text already filled in
- [ ] Events page shows all sample events, soonest first
- [ ] Search by a word in a title works (for example "summit")
- [ ] Search by a location works (for example "sylhet")
- [ ] Category filter works, and works together with search
- [ ] Free only and Paid only work
- [ ] Each Sort option puts the cards in the right order
- [ ] Clear filters resets search, filters, and sort
- [ ] A search with no match shows "No events found"

## Attendee: details and registration

- [ ] A card opens the correct details page
- [ ] `event-details.html?id=999` shows "Event not found" with a link back
- [ ] Register button opens the form with that event selected
- [ ] Total price updates when the ticket number changes
- [ ] Empty name, bad email, 0 tickets, and 1.5 tickets are all blocked with a message
- [ ] More tickets than are left is blocked
- [ ] A valid registration shows a confirmation with a registration number
- [ ] After a refresh, "tickets left" has dropped
- [ ] The confirmation shows a ticket code like EVT-XXXX-XXXX and a "View my ticket" button
- [ ] The ticket page shows the event, your name, number of people, and a QR code
- [ ] "My Ticket" in the menu, with the wrong email, shows an error; with the right email and code (any letter case) opens the ticket
- [ ] Print or save as PDF shows only the ticket
- [ ] Registering until an event is full shows "Sold out" on its card and details page, and the Register button is disabled

## Organizer

- [ ] Stats show the right number of events and registrations
- [ ] The registrations table shows name, email, event, tickets, and date
- [ ] Adding an event with empty fields shows errors next to each field
- [ ] Adding a valid event works, and it appears on the Events page
- [ ] Edit loads the event into the form, and saving changes it without making a duplicate
- [ ] Capacity cannot be set below the tickets already registered
- [ ] The registrations table shows each ticket code and its status
- [ ] Check-in with a valid code says how many people to admit, and the "Tickets checked in" number goes up
- [ ] The same code a second time says "Already checked in"; a made-up code says "Invalid ticket"
- [ ] The Check in and Undo buttons in the table work
- [ ] Cancel edit clears the form
- [ ] Delete asks for confirmation, then removes the event and its registrations
- [ ] Deleting every event shows "No events yet", and the Events page says so too
- [ ] Reset demo data restores the 10 sample events

## Edge cases

- [ ] Refresh each page: data is still there
- [ ] Type `<b>bold</b>` as an event title: it shows as text, not bold
- [ ] In DevTools, Application, Local Storage: type invalid text into `eventify_events`, reload, and the site still works
- [ ] Browser Console shows no red errors on any page

## Layout and accessibility

- [ ] Every page looks right at 320px, 375px, 768px, and 1280px wide (DevTools device mode)
- [ ] No page scrolls sideways
- [ ] The phone menu opens, closes after choosing a link, and closes with Escape
- [ ] You can reach every link, button, and field using only the Tab key, and you can always see which one is focused
- [ ] The first Tab on any page shows "Skip to main content"
- [ ] Every form field has a visible label

## Notes

Write any bug you find here, with the page and the steps to repeat it:

-
