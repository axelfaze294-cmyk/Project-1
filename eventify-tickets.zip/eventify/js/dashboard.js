// dashboard.js: organizer dashboard (create, read, update, delete events; view registrations).
// Needs data.js, storage.js, and main.js to be loaded first.

// Picture used for a new event when the organizer leaves the image field empty.
const CATEGORY_IMAGES = {
  Technology: "images/events/tech.svg",
  Music: "images/events/music.svg",
  Business: "images/events/business.svg",
  Art: "images/events/art.svg",
  Sports: "images/events/sports.svg",
  Food: "images/events/food.svg",
  Education: "images/events/education.svg"
};

function defaultImageFor(category) {
  return CATEGORY_IMAGES[category] || "images/events/default.svg";
}

// A new event id: one higher than the biggest existing id.
function nextEventId(events) {
  const ids = events.map((event) => Number(event.id) || 0);
  return Math.max(0, ...ids) + 1;
}

function initDashboard() {
  const form = document.getElementById("eventForm");
  if (!form) return;

  const formCard = form.closest(".form-card");
  const formHeading = document.getElementById("formHeading");
  const formNotice = document.getElementById("formNotice");
  const idField = document.getElementById("eventId");
  const saveButton = document.getElementById("saveEventBtn");
  const cancelButton = document.getElementById("cancelEditBtn");
  const resetDataButton = document.getElementById("resetDataBtn");

  const titleInput = document.getElementById("title");
  const categorySelect = document.getElementById("category");
  const dateInput = document.getElementById("date");
  const locationInput = document.getElementById("location");
  const priceInput = document.getElementById("price");
  const capacityInput = document.getElementById("capacity");
  const imageInput = document.getElementById("image");
  const descriptionInput = document.getElementById("description");

  // Each form field, paired with the element that shows its error message.
  const fields = [
    [titleInput, document.getElementById("titleError")],
    [dateInput, document.getElementById("dateError")],
    [locationInput, document.getElementById("locationError")],
    [priceInput, document.getElementById("priceError")],
    [capacityInput, document.getElementById("capacityError")],
    [descriptionInput, document.getElementById("descriptionError")]
  ];

  fields.forEach(([input, error]) => input.setAttribute("aria-describedby", error.id));

  /* ---------- Messages ---------- */

  function showNotice(message, isError = false) {
    formNotice.textContent = message;
    formNotice.classList.toggle("error", isError);
    formNotice.hidden = false;
  }

  function hideNotice() {
    formNotice.hidden = true;
    formNotice.textContent = "";
  }

  function clearErrors() {
    fields.forEach(([input, error]) => showFieldError(input, error, ""));
  }

  /* ---------- Reading: stats and tables ---------- */

  function renderAll() {
    const events = getEvents();
    const registrations = getRegistrations();
    const editingId = idField.value;

    // Tickets registered per event, counted once for the whole table.
    const ticketsByEvent = getTicketsSoldMap();

    // Stats
    document.getElementById("statEvents").textContent = events.length;
    document.getElementById("statRegistrations").textContent = registrations.length;
    document.getElementById("statCheckedIn").textContent = registrations
      .filter((registration) => registration.checkedIn)
      .reduce((sum, registration) => sum + (Number(registration.quantity) || 0), 0);

    // Events table
    const eventsBody = document.getElementById("eventsTableBody");

    eventsBody.innerHTML = sortByDate(events).map((event) => {
      const id = escapeHtml(event.id);
      const title = escapeHtml(event.title);
      const sold = ticketsByEvent[String(event.id)] || 0;
      const isEditing = editingId !== "" && editingId === String(event.id);

      return `
        <tr${isEditing ? ' class="editing"' : ""}>
          <td><a href="event-details.html?id=${encodeURIComponent(event.id)}">${title}</a></td>
          <td>${escapeHtml(formatDate(event.date))}</td>
          <td>${escapeHtml(event.location || "-")}</td>
          <td>${sold} / ${escapeHtml(Number(event.capacity) || 0)}</td>
          <td class="actions">
            <button type="button" class="btn btn-small btn-outline" data-action="edit" data-id="${id}" aria-label="Edit ${title}">Edit</button>
            <button type="button" class="btn btn-small btn-danger" data-action="delete" data-id="${id}" aria-label="Delete ${title}">Delete</button>
          </td>
        </tr>
      `;
    }).join("");

    document.getElementById("noEvents").hidden = events.length > 0;

    // Registrations table, newest first
    const titlesById = {};
    events.forEach((event) => {
      titlesById[String(event.id)] = event.title;
    });

    const newestFirst = [...registrations].sort(
      (a, b) => String(b.date).localeCompare(String(a.date))
    );

    document.getElementById("registrationsTableBody").innerHTML = newestFirst.map((registration) => `
      <tr>
        <td>${escapeHtml(registration.name || "-")}</td>
        <td>${escapeHtml(registration.email || "-")}</td>
        <td>${escapeHtml(titlesById[String(registration.eventId)] || "Unknown event")}</td>
        <td>${escapeHtml(Number(registration.quantity) || 0)}</td>
        <td class="code-cell">${escapeHtml(registration.code || "-")}</td>
        <td class="status-cell">${registration.checkedIn
          ? '<span class="status-pill used">Checked in</span>'
          : '<span class="status-pill valid">Not yet</span>'}
          ${registration.checkedIn
          ? `<button type="button" class="btn btn-small btn-outline" data-checkin="undo" data-code="${escapeHtml(registration.code)}" aria-label="Undo check-in for ${escapeHtml(registration.name || "attendee")}">Undo</button>`
          : `<button type="button" class="btn btn-small" data-checkin="do" data-code="${escapeHtml(registration.code)}" aria-label="Check in ${escapeHtml(registration.name || "attendee")}">Check in</button>`}</td>
        <td>${escapeHtml(formatDateTime(registration.date))}</td>
      </tr>
    `).join("");

    document.getElementById("noRegistrations").hidden = registrations.length > 0;
  }

  /* ---------- Form modes: add and edit ---------- */

  function exitEditMode() {
    form.reset();
    idField.value = "";
    clearErrors();
    formHeading.textContent = "Add a new event";
    saveButton.textContent = "Save event";
    cancelButton.hidden = true;
    formCard.classList.remove("editing");
  }

  function startEdit(event) {
    hideNotice();
    clearErrors();

    idField.value = String(event.id);
    titleInput.value = event.title || "";

    // If the saved category is not in the list, add it so it can be shown.
    const category = event.category || categorySelect.options[0].value;
    if (![...categorySelect.options].some((option) => option.value === category)) {
      categorySelect.add(new Option(category, category));
    }
    categorySelect.value = category;

    dateInput.value = event.date || "";
    locationInput.value = event.location || "";
    priceInput.value = Number(event.price) || 0;
    capacityInput.value = Number(event.capacity) || 1;
    imageInput.value = event.image || "";
    descriptionInput.value = event.description || "";

    formHeading.textContent = "Edit event";
    saveButton.textContent = "Update event";
    cancelButton.hidden = false;
    formCard.classList.add("editing");

    renderAll();
    formCard.scrollIntoView({ behavior: "smooth", block: "start" });
    titleInput.focus({ preventScroll: true });
  }

  /* ---------- Validation: each function returns an error message, or "" if valid ----------
     "editingId" is "" when adding a new event. */

  function validateForm(editingId) {
    const title = titleInput.value.trim();
    const date = dateInput.value.trim();
    const location = locationInput.value.trim();
    const priceText = priceInput.value.trim();
    const capacityText = capacityInput.value.trim();
    const description = descriptionInput.value.trim();

    const price = Number(priceText);
    const capacity = Number(capacityText);

    const messages = new Map();

    // Title
    if (title === "") messages.set(titleInput, "Please enter a title.");
    else if (title.length > 100) messages.set(titleInput, "The title must be 100 characters or fewer.");

    // Date (the date picker gives YYYY-MM-DD; check it is a real calendar date)
    const parts = date.split("-").map(Number);
    const parsed = new Date(parts[0], parts[1] - 1, parts[2]);
    const realDate = /^\d{4}-\d{2}-\d{2}$/.test(date) &&
      parsed.getFullYear() === parts[0] &&
      parsed.getMonth() === parts[1] - 1 &&
      parsed.getDate() === parts[2];

    if (date === "") messages.set(dateInput, "Please choose a date.");
    else if (!realDate) messages.set(dateInput, "Please enter a valid date.");

    // Location
    if (location === "") messages.set(locationInput, "Please enter a location.");
    else if (location.length > 100) messages.set(locationInput, "The location must be 100 characters or fewer.");

    // Price
    if (priceText === "") {
      messages.set(priceInput, "Please enter a price. Use 0 for a free event.");
    } else if (!Number.isInteger(price) || price < 0) {
      messages.set(priceInput, "The price must be a whole number, 0 or more.");
    }

    // Capacity
    if (capacityText === "" || !Number.isInteger(capacity) || capacity < 1) {
      messages.set(capacityInput, "Capacity must be a whole number, 1 or more.");
    } else if (capacity > 100000) {
      messages.set(capacityInput, "Capacity must be 100,000 or fewer.");
    } else if (editingId !== "") {
      // Capacity cannot drop below tickets that are already registered.
      const sold = getTicketsSold(editingId);

      if (capacity < sold) {
        messages.set(capacityInput, `Capacity cannot be lower than the ${sold} ${ticketWord(sold)} already registered.`);
      }
    }

    // Description
    if (description === "") messages.set(descriptionInput, "Please enter a description.");
    else if (description.length > 1000) messages.set(descriptionInput, "The description must be 1000 characters or fewer.");

    // Show every message at once (and clear the ones that are now fine).
    fields.forEach(([input, error]) => showFieldError(input, error, messages.get(input) || ""));

    const firstProblem = fields.find(([input]) => messages.has(input));
    if (firstProblem) {
      return { valid: false, firstInvalid: firstProblem[0] };
    }

    const category = categorySelect.value;
    const image = imageInput.value.trim();

    return {
      valid: true,
      values: {
        title: title,
        category: category,
        date: date,
        location: location,
        price: price,
        capacity: capacity,
        image: image || defaultImageFor(category),
        description: description
      }
    };
  }

  /* ---------- Create and update ---------- */

  form.addEventListener("submit", (submitEvent) => {
    submitEvent.preventDefault();
    hideNotice();

    const editingId = idField.value;
    const result = validateForm(editingId);

    if (!result.valid) {
      result.firstInvalid.focus();
      return;
    }

    // Read the saved events again, in case they changed in another tab.
    const events = getEvents();

    if (editingId !== "") {
      const index = events.findIndex((event) => String(event.id) === editingId);

      if (index === -1) {
        exitEditMode();
        renderAll();
        showNotice("That event no longer exists. It may have been deleted in another tab.", true);
        return;
      }

      events[index] = { ...events[index], ...result.values };
    } else {
      events.push({ id: nextEventId(events), ...result.values });
    }

    if (!saveEvents(events)) {
      showNotice("The event could not be saved. Your browser storage may be full or blocked.", true);
      return;
    }

    const message = editingId !== "" ? "Event updated." : "Event added.";
    exitEditMode();
    renderAll();
    showNotice(message);
  });

  // Clear a field's error message as soon as the organizer changes it.
  fields.forEach(([input, error]) => {
    input.addEventListener("input", () => showFieldError(input, error, ""));
  });

  cancelButton.addEventListener("click", () => {
    exitEditMode();
    hideNotice();
    renderAll();
  });

  /* ---------- Edit and delete buttons in the events table ---------- */

  document.getElementById("eventsTableBody").addEventListener("click", (clickEvent) => {
    const button = clickEvent.target.closest("button[data-action]");
    if (!button) return;

    const events = getEvents();
    const event = events.find((item) => String(item.id) === button.dataset.id);

    if (!event) {
      renderAll();
      showNotice("That event no longer exists. The list has been refreshed.", true);
      return;
    }

    if (button.dataset.action === "edit") {
      startEdit(event);
    } else if (button.dataset.action === "delete") {
      deleteEvent(event, events);
    }
  });

  function deleteEvent(event, events) {
    const related = getRegistrations().filter(
      (registration) => String(registration.eventId) === String(event.id)
    );

    let question = `Delete "${event.title}"?`;
    if (related.length > 0) {
      question += ` Its ${related.length} ${related.length === 1 ? "registration" : "registrations"} will be deleted too.`;
    }
    question += " This cannot be undone.";

    if (!window.confirm(question)) return;

    const remainingEvents = events.filter((item) => String(item.id) !== String(event.id));

    if (!saveEvents(remainingEvents)) {
      showNotice("The event could not be deleted. Your browser storage may be full or blocked.", true);
      return;
    }

    // Remove the registrations that belonged to the deleted event.
    const remainingRegistrations = getRegistrations().filter(
      (registration) => String(registration.eventId) !== String(event.id)
    );
    saveRegistrations(remainingRegistrations);

    // If that event was open in the form, close the form.
    if (idField.value === String(event.id)) {
      exitEditMode();
    }

    renderAll();
    showNotice(`"${event.title}" was deleted.`);
  }

  /* ---------- Check-in ---------- */

  const checkinForm = document.getElementById("checkinForm");
  const checkinInput = document.getElementById("checkinCode");
  const checkinResult = document.getElementById("checkinResult");

  function showCheckinResult(message, kind) {
    checkinResult.textContent = message;
    checkinResult.className = `checkin-result ${kind}`;
    checkinResult.hidden = false;
  }

  function eventTitleFor(registration) {
    const event = getEvents().find((item) => String(item.id) === String(registration.eventId));
    return event ? event.title : "an event";
  }

  checkinForm.addEventListener("submit", (submitEvent) => {
    submitEvent.preventDefault();
    const registration = findRegistrationByCode(checkinInput.value);

    if (normalizeTicketCode(checkinInput.value) === "") {
      showCheckinResult("Enter a ticket code.", "error");
      checkinInput.focus();
      return;
    }

    if (!registration) {
      showCheckinResult("Invalid ticket: no registration has that code.", "error");
    } else if (registration.checkedIn) {
      showCheckinResult(
        `Already checked in: ${registration.name} (${eventTitleFor(registration)}) was checked in on ${formatDateTime(registration.checkedInAt)}. Do not admit again.`,
        "error"
      );
    } else if (markCheckedIn(registration.code)) {
      const count = Number(registration.quantity) || 0;
      showCheckinResult(
        `Checked in: ${registration.name}, ${eventTitleFor(registration)}. Admit ${count} ${count === 1 ? "person" : "people"}.`,
        "success"
      );
      renderAll();
    } else {
      showCheckinResult("The check-in could not be saved. Your browser storage may be full or blocked.", "error");
    }

    checkinInput.value = "";
    checkinInput.focus();
  });

  // "Check in" / "Undo" buttons in the registrations table (for attendees without their QR code).
  document.getElementById("registrationsTableBody").addEventListener("click", (clickEvent) => {
    const button = clickEvent.target.closest("button[data-checkin]");
    if (!button) return;

    const updated = markCheckedIn(button.dataset.code, button.dataset.checkin === "do");
    renderAll();

    if (!updated) {
      showCheckinResult("That registration could not be updated.", "error");
    }
  });

  /* ---------- Reset demo data ---------- */

  resetDataButton.addEventListener("click", () => {
    const question = "Reset to the sample events and delete all registrations? Your changes will be lost.";
    if (!window.confirm(question)) return;

    const savedEvents = saveEvents(initialEvents.map((event) => ({ ...event })));
    const savedRegistrations = saveRegistrations([]);

    exitEditMode();
    renderAll();

    if (savedEvents && savedRegistrations) {
      showNotice("Demo data was reset.");
    } else {
      showNotice("The demo data could not be reset. Your browser storage may be full or blocked.", true);
    }
  });

  renderAll();
}

document.addEventListener("DOMContentLoaded", initDashboard);
