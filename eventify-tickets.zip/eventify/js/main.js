// main.js: shared navigation, shared helper functions, and footer year.
// This file is loaded on every page, before the page's own script.

/* ---------- Shared helpers (used by several pages) ---------- */

// Make text safe to place inside HTML. Always use this for text that a user
// could type (event titles, names, descriptions) before putting it in innerHTML.
function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

// "2026-11-20" becomes "20 Nov 2026". Returns the original text if it is not a valid date.
function formatDate(isoDate) {
  const [year, month, day] = String(isoDate).split("-").map(Number);
  const date = new Date(year, month - 1, day);

  if (!year || !month || !day || Number.isNaN(date.getTime())) {
    return String(isoDate);
  }

  return date.toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric"
  });
}

// 0 becomes "Free"; 1500 becomes "৳1,500".
function formatPrice(price) {
  const amount = Number(price);

  if (!amount) {
    return "Free";
  }

  return "৳" + amount.toLocaleString("en-US");
}

// Returns a new list sorted by date, soonest first.
function sortByDate(events) {
  return [...events].sort((a, b) => String(a.date).localeCompare(String(b.date)));
}

// "ticket" or "tickets", depending on the number.
function ticketWord(count) {
  return count === 1 ? "ticket" : "tickets";
}

// Shows (or clears) an error message under a form field and marks the field as invalid.
function showFieldError(input, errorElement, message) {
  errorElement.textContent = message;
  input.classList.toggle("invalid", message !== "");
  input.setAttribute("aria-invalid", message !== "" ? "true" : "false");
}

// "2026-10-11T08:30:00.000Z" becomes "11 Oct 2026, 14:30" (in the visitor's own time zone).
function formatDateTime(isoString) {
  const date = new Date(isoString);

  if (Number.isNaN(date.getTime())) {
    return "-";
  }

  return date.toLocaleString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
}

// Today's date as "YYYY-MM-DD" in the visitor's own time zone.
function todayISO() {
  const now = new Date();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${now.getFullYear()}-${month}-${day}`;
}

/* ---------- Navigation and footer ---------- */

document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.getElementById("navToggle");
  const navLinks = document.getElementById("navLinks");
  const year = document.getElementById("year");

  // Mobile menu: show or hide the links when the button is clicked
  if (toggle && navLinks) {
    const setMenu = (isOpen) => {
      navLinks.classList.toggle("open", isOpen);
      toggle.setAttribute("aria-expanded", String(isOpen));
    };

    toggle.addEventListener("click", () => {
      setMenu(!navLinks.classList.contains("open"));
    });

    // Close the menu after a link is chosen (in-page links like About do not reload the page).
    navLinks.addEventListener("click", (event) => {
      if (event.target.closest("a")) {
        setMenu(false);
      }
    });

    // Escape closes the menu and returns focus to the menu button.
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && navLinks.classList.contains("open")) {
        setMenu(false);
        toggle.focus();
      }
    });
  }

  // Keep the footer year current
  if (year) {
    year.textContent = new Date().getFullYear();
  }
});
