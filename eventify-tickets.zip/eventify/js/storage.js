// storage.js: reading and writing browser storage (localStorage)
// Load this file after data.js and before any script that uses these functions.

const EVENTS_KEY = "eventify_events";
const REGISTRATIONS_KEY = "eventify_registrations";

// Read and parse a saved value. Returns `fallback` if nothing is saved,
// the saved text is not valid JSON, or storage is unavailable.
function readData(key, fallback = []) {
  try {
    const value = localStorage.getItem(key);

    return value === null
      ? fallback
      : JSON.parse(value);
  } catch {
    return fallback;
  }
}

// Save a value as JSON. Returns true on success, false if storage failed
// (for example, storage is full or blocked in a private window).
function writeData(key, data) {
  try {
    localStorage.setItem(key, JSON.stringify(data));
    return true;
  } catch {
    return false;
  }
}

// An event is usable only if it is an object with an id and a title.
function isValidEvent(event) {
  return Boolean(
    event &&
    typeof event === "object" &&
    event.id !== undefined &&
    event.id !== null &&
    typeof event.title === "string" &&
    event.title.trim() !== ""
  );
}

// Get all events. On the first visit (or if the saved data is damaged),
// save the sample events and return them. Unusable entries are skipped.
function getEvents() {
  const saved = readData(EVENTS_KEY, null);

  if (!Array.isArray(saved)) {
    writeData(EVENTS_KEY, initialEvents);
    return initialEvents.map((event) => ({ ...event }));
  }

  return saved.filter(isValidEvent);
}

function saveEvents(events) {
  return writeData(EVENTS_KEY, events);
}

// Get all registrations. Always returns an array of objects.
// Older registrations that have no ticket code get one here, once.
function getRegistrations() {
  const saved = readData(REGISTRATIONS_KEY, []);

  if (!Array.isArray(saved)) {
    return [];
  }

  const registrations = saved.filter((item) => item && typeof item === "object");
  let changed = false;

  registrations.forEach((registration) => {
    if (!registration.code) {
      registration.code = generateTicketCode(registrations);
      changed = true;
    }
  });

  if (changed) {
    writeData(REGISTRATIONS_KEY, registrations);
  }

  return registrations;
}

function saveRegistrations(registrations) {
  return writeData(REGISTRATIONS_KEY, registrations);
}

// Tickets registered for every event, counted in one pass.
// Returns an object like { "1": 12, "3": 40 } (event id -> tickets sold).
function getTicketsSoldMap() {
  const sold = {};

  getRegistrations().forEach((registration) => {
    const key = String(registration.eventId);
    sold[key] = (sold[key] || 0) + (Number(registration.quantity) || 0);
  });

  return sold;
}

// How many tickets have been registered for one event.
function getTicketsSold(eventId) {
  return getTicketsSoldMap()[String(eventId)] || 0;
}

// Tickets still available: capacity minus tickets already registered.
function getRemainingTickets(event) {
  const capacity = Number(event.capacity) || 0;
  return Math.max(0, capacity - getTicketsSold(event.id));
}

/* ---------- Ticket codes ---------- */

// Letters and digits that are easy to read aloud (no 0/O, 1/I/L).
const TICKET_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";

function randomTicketPart(length) {
  const values = new Uint32Array(length);
  window.crypto.getRandomValues(values);
  return Array.from(values, (value) => TICKET_ALPHABET[value % TICKET_ALPHABET.length]).join("");
}

// A random code like EVT-7K3Q-9XMD that is not used by any registration in the list.
function generateTicketCode(registrations) {
  const used = new Set(registrations.map((registration) => registration.code).filter(Boolean));
  let code;

  do {
    code = `EVT-${randomTicketPart(4)}-${randomTicketPart(4)}`;
  } while (used.has(code));

  return code;
}

// Makes typed codes comparable: "evt 7k3q 9xmd" and "EVT-7K3Q-9XMD" are the same code.
function normalizeTicketCode(text) {
  return String(text || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
}

function findRegistrationByCode(code) {
  const wanted = normalizeTicketCode(code);
  if (wanted === "") return null;

  return getRegistrations().find((registration) => normalizeTicketCode(registration.code) === wanted) || null;
}

// Marks a registration as checked in (or undoes it with checkedIn = false).
// Returns the updated registration, or null if it was not found or saving failed.
function markCheckedIn(code, checkedIn = true) {
  const wanted = normalizeTicketCode(code);
  const registrations = getRegistrations();
  const registration = registrations.find((item) => normalizeTicketCode(item.code) === wanted);

  if (!registration) return null;

  registration.checkedIn = checkedIn;
  registration.checkedInAt = checkedIn ? new Date().toISOString() : null;

  return saveRegistrations(registrations) ? registration : null;
}
