// ticket.js: shows a registration as an entry pass with a QR code, and finds a ticket by email + code.
// Needs data.js, storage.js, main.js, and vendor/qrcode.js to be loaded first.

// Draws the QR code for a ticket code. The QR holds only the code text.
function renderQrCode(container, text) {
  try {
    const qr = qrcode(0, "M");   // type 0 = pick the smallest size that fits
    qr.addData(text);
    qr.make();
    container.innerHTML = qr.createSvgTag({ cellSize: 6, margin: 2, scalable: true });
  } catch (error) {
    container.textContent = "QR code unavailable. Use the code below.";
  }
}

function initTicketPage() {
  const lookupSection = document.getElementById("lookupSection");
  const ticketSection = document.getElementById("ticketSection");
  if (!lookupSection || !ticketSection) return;

  const lookupForm = document.getElementById("lookupForm");
  const emailInput = document.getElementById("lookupEmail");
  const emailError = document.getElementById("lookupEmailError");
  const codeInput = document.getElementById("lookupCode");
  const codeError = document.getElementById("lookupCodeError");
  const formError = document.getElementById("lookupFormError");

  [[emailInput, emailError], [codeInput, codeError]].forEach(([input, error]) => {
    input.setAttribute("aria-describedby", error.id);
    input.addEventListener("input", () => {
      showFieldError(input, error, "");
      formError.textContent = "";
    });
  });

  function showTicket(registration) {
    const events = getEvents();
    const event = events.find((item) => String(item.id) === String(registration.eventId));
    const total = Number(registration.total) || 0;
    const quantity = Number(registration.quantity) || 1;

    document.getElementById("ticketHeading").textContent = event ? event.title : "Event";
    document.getElementById("ticketDate").textContent = event ? formatDate(event.date) : "-";
    document.getElementById("ticketLocation").textContent = (event && event.location) || "-";
    document.getElementById("ticketName").textContent = registration.name || "-";
    document.getElementById("ticketAdmits").textContent = `${quantity} ${quantity === 1 ? "person" : "people"}`;
    document.getElementById("ticketTotal").textContent = total === 0 ? "Free" : formatPrice(total);
    document.getElementById("ticketNumber").textContent = `#${registration.id}`;
    document.getElementById("ticketCode").textContent = registration.code;

    const status = document.getElementById("ticketStatus");
    if (registration.checkedIn) {
      status.textContent = `Already checked in${registration.checkedInAt ? " on " + formatDateTime(registration.checkedInAt) : ""}`;
      status.className = "ticket-status used";
    } else {
      status.textContent = "Valid: not used yet";
      status.className = "ticket-status valid";
    }

    renderQrCode(document.getElementById("ticketQr"), registration.code);

    lookupSection.hidden = true;
    ticketSection.hidden = false;
    document.title = `Ticket ${registration.code} | Eventify`;

    const heading = document.getElementById("ticketHeading");
    heading.tabIndex = -1;
    heading.focus();
  }

  lookupForm.addEventListener("submit", (submitEvent) => {
    submitEvent.preventDefault();
    formError.textContent = "";

    const email = emailInput.value.trim();
    const code = codeInput.value.trim();

    const emailMessage = email === "" ? "Please enter your email address."
      : !EMAIL_PATTERN_TICKET.test(email) ? "Please enter a valid email address, like name@example.com." : "";
    const codeMessage = normalizeTicketCode(code) === "" ? "Please enter your ticket code." : "";

    showFieldError(emailInput, emailError, emailMessage);
    showFieldError(codeInput, codeError, codeMessage);

    if (emailMessage || codeMessage) {
      (emailMessage ? emailInput : codeInput).focus();
      return;
    }

    const registration = findRegistrationByCode(code);

    // Same message for a wrong code and a wrong email, so nobody can probe which codes exist.
    if (!registration || String(registration.email).toLowerCase() !== email.toLowerCase()) {
      formError.textContent = "No ticket matches that email and code. Check both and try again.";
      return;
    }

    history.replaceState(null, "", `ticket.html?code=${encodeURIComponent(registration.code)}`);
    showTicket(registration);
  });

  document.getElementById("printTicketBtn").addEventListener("click", () => window.print());

  // Opened from the confirmation page: ticket.html?code=EVT-XXXX-XXXX
  const requestedCode = new URLSearchParams(window.location.search).get("code");
  if (requestedCode !== null) {
    const registration = findRegistrationByCode(requestedCode);

    if (registration) {
      showTicket(registration);
    } else {
      formError.textContent = "We could not find a ticket with that code in this browser. Enter your email and ticket code below.";
    }
  }
}

const EMAIL_PATTERN_TICKET = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

document.addEventListener("DOMContentLoaded", initTicketPage);
